"""
Description:
    This module provides a function to convert XML files containing input and output features into Parquet format.
    It is specifically designed to handle the structure of the articles-bypublisher and ground-truth-bypublisher XML datasets.

Author:
    Osvaldo Hernandez-Segura

Date Created:
    November 25, 2025

Date Modified:
    November 25, 2025

References:
    Copilot, ChatGPT, lxml documentation, pandas documentation
"""
import os
import pandas as pd

from lxml import etree

def convert_xml_to_parquet(xml_file_path_input_features: str, xml_file_path_output_features: str, parquet_file_path: str) -> None:
    """
    Convert XML files to Parquet format for the articles-bypublisher and 
    ground-truth-bypublisher XML datasets.

    Note that this function is specifically designed to handle the structure 
    of these datasets.

     Data Example (Truncated):
        A. input features: id, published-at, title, text, source
        <article id="0000012" published-at="2016-09-26" title="Jewish Organization's Huge Day Of Unity On Tuesday">
        <p>The Jewish organization, StandWithUs, is hosting a huge day of unity on Tuesday, September 27th...</p>...

        B. output features: id, hyperpartisan, bias, url, labeled-by
          <article id="0000012" hyperpartisan="true" bias="right" url="https://dailywire.com/node/9485" labeled-by="publisher"/>
          
        C. Combined features in order: id, published-at, title, text, source, hyperpartisan, bias, url, labeled-by

    Notes:
        1. The goal of this function is to combine the input and output features into a single Parquet file.

    Args:
        xml_file_path_input_features (str): Path to the input XML file containing input features.
        xml_file_path_output_features (str): Path to the input XML file containing output features.
        parquet_file_path (str): Path to the output Parquet file.

    Raises:
        ValueError: If input file paths are None.
        RuntimeError: If conversion fails.
    """

    def open_xml_file(xml_file_path: str):
        """
        Open and parse an XML file.

        Args:
            xml_file_path (str): Path to the XML file.

        Raises:
            FileNotFoundError: If the XML file does not exist.
            RuntimeError: If there is an error parsing the XML file.

        Returns:
            etree._ElementTree: Parsed XML tree.
        """
        if not os.path.exists(xml_file_path):
            raise FileNotFoundError(f"XML file not found: {xml_file_path}")
        try:
            return etree.parse(xml_file_path)
        except etree.XMLSyntaxError as e:
            raise RuntimeError(f"XML syntax error while parsing {xml_file_path}: {e}")

    def insert_dict_to_parquet(data_dict: dict, parquet_file_path: str) -> None:
        """
        Insert a dictionary into a Parquet file.

        Args:
            data_dict (dict): Dictionary containing the data to be inserted.
            parquet_file_path (str): Path to the output Parquet file.

        Raises:
            RuntimeError: If there is an error during insertion.
        """
        try:
            df = pd.DataFrame.from_dict(data_dict, orient='index')
            df.to_parquet(parquet_file_path, engine='pyarrow', index=False)
            print(f"Data successfully written to Parquet file: {parquet_file_path}")
        except Exception as e:
            raise RuntimeError(f"Failed to insert data into Parquet file: {e}")

    empty_paths = not xml_file_path_input_features and not xml_file_path_output_features and not parquet_file_path
    invalid_paths = not os.path.exists(xml_file_path_input_features) or not os.path.exists(xml_file_path_output_features) 
    if empty_paths:
        raise ValueError("Input and output file paths must not be None.")
    if invalid_paths:
        raise ValueError("One or more input file paths do not exist.")
    try:
        # open the XML input file
        tree_input_features = open_xml_file(xml_file_path_input_features)
        root_input_features = tree_input_features.getroot()

        # convert xml input features to dict -> dict of data
        input_features = dict()
        for article in root_input_features.findall('article'):
            article_id = article.get('id')
            published_at = article.get('published-at')
            title = article.get('title')

            # find text from nested <p> tags, ingoring other tags, such as <a>
            text = []
            for paragraph in article.findall('p'):
                if paragraph.text:
                    # clean text
                    paragraph = " ".join(paragraph.text.strip().split())
                    text.append(paragraph)

            # join paragraphs into single text
            text = " ".join(text)

            # store data into dict
            input_features[article_id] = {
                    'id': article_id,
                    'published_at': published_at,
                    'title': title,
                    'text': text
                    } 

        # open the XML output file
        tree_output_features = open_xml_file(xml_file_path_output_features)
        root_input_features = tree_output_features.getroot()

        # convert xml output features to dict -> dict of data
        output_features = dict()
        for article in root_input_features.findall('article'):
            article_id = article.get('id')
            hyperpartisan = article.get('hyperpartisan')
            bias = article.get('bias')
            url = article.get('url')
            labeled_by = article.get('labeled-by')

            # store data into dict
            output_features[article_id] = {
                    'hyperpartisan': hyperpartisan,
                    'bias': bias,
                    'url': url,
                    'labeled_by': labeled_by
                    }

        # combine input and output features dicts
        combined_features = dict()
        for article_id in input_features.keys():
            if article_id in output_features:
                combined_features[article_id] = {**input_features[article_id], **output_features[article_id]}
            else:
                combined_features[article_id] = input_features[article_id]

        # insert combined dict to parquet
        insert_dict_to_parquet(combined_features, parquet_file_path)

    except Exception as e:
        raise RuntimeError(f"Failed to convert XML to Parquet: {e}")

