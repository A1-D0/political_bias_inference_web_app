"""
Description:
    This script contains the preprocessing functions and pipelines 
    for machine learning training, validation, and evaulation. 
    Particularly, for the baseline ML models for the US News domain.

Author:
    Osvaldo Hernandez-Segura

Date Created:
    December 3, 2025

Last Modified:
    December 10, 2025

References:
    Copilot, ChatGPT, scikit-learn documentation
"""
import os
import pandas as pd
import numpy as np
import time

from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from transformers import DebertaV2Tokenizer
from utils.data_preprocessing import TokenizerSentenceTransformer
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.dummy import DummyClassifier
from sklearn.metrics import (f1_score, precision_score, recall_score, 
                             balanced_accuracy_score,  
                             classification_report, make_scorer)
from sklearn.model_selection import train_test_split

# ------------- Baseline data preprocessing classes and functions ------------- 

def get_column_preprocessing_pipeline(text_column: str, 
                                        model_option: str='all-mpnet-base-v2',
                                        batch_size: int=64,
                                        keep_unprocessed_data: bool=False)-> ColumnTransformer:
    """
    Create a data preprocessing pipeline for the scikit-learn-based baseline model.
    Note that there are other small and larger model options that can be used in 
    this pipeline from the sentence-transformers library. Adjust the model_option parameter
    to select a different model based on the use case and computational resources.

    The default tokenizer (model option) has:
        1. embedding dimension of 768
        2. max sequence length of 512 tokens

    Args:
        text_column (str): The name of the text column to be processed.
        model_option (str): The sentence transformer model to use for text embedding. Defaults to 'all-mpnet-base-v2'.
        batch_size (int): The batch size for processing text data. Defaults to 64.
        keep_unprocessed_data (bool): Whether to keep unprocessed data in the output. Defaults to False.

    Returns:
        ColumnTransformer: A scikit-learn ColumnTransformer object for data preprocessing.
    """
    print("Initializing scikit-learn baseline column preprocessing pipeline...")
    preprocessor = ColumnTransformer(
            transformers=[
                ('tokenizer', TokenizerSentenceTransformer(model_option=model_option, batch_size=batch_size), [text_column])
                ],
            remainder='passthrough' if keep_unprocessed_data else 'drop'
            )
    return preprocessor

def get_data_preprocessing_pipeline(model, 
                                    text_column: str, 
                                    model_option: str='all-mpnet-base-v2',
                                    batch_size: int=64,
                                    keep_unprocessed_data: bool=False,
                                    caching_path: str | None = None,
                                    include_preprocessing: bool=False)-> Pipeline:
    """
    Create a data preprocessing pipeline for a scikit-learn-based ML classification model.
    Note that there are other small and larger model options that can be used in 
    this pipeline from the sentence-transformers library. Adjust the model_option parameter
    to select a different model based on the use case and computational resources.
    Caching is included to speed up the pipeline processing at the cost of disk space use.

    The default tokenizer (model option) has:
        1. embedding dimension of 768
        2. max sequence length of 512 tokens

    Args:
        model: A scikit-learn ML classification model to be used in the pipeline.
        text_column (str): The name of the text column to be processed.
        model_option (str): The sentence transformer model to use for text embedding. Defaults to 'all-mpnet-base-v2'.
        batch_size (int): The batch size for processing text data. Defaults to 64.
        keep_unprocessed_data (bool): Whether to keep unprocessed data in the output. Defaults to False.
        caching_path (str): Path to use for caching the pipeline steps (Optional).
        include_preprocessing (bool): Whether to include the preprocessing step in the pipeline. Defaults to False.

    Returns:
        Pipeline: A scikit-learn Pipeline object for data preprocessing.
    """
    print("Initializing scikit-learn data preprocessing pipeline...")
    if not model:
        raise ValueError("A scikit-learn model must be provided for the pipeline to be initiated.")
    if caching_path:
        dir_path = os.path.dirname(caching_path)
        if not os.path.exists(dir_path):
            raise IOError(f"Directory {dir_path} does not exist for caching path.")
        print(f"Caching pipeline steps to: {caching_path}")

    preprocessor = None
    if include_preprocessing:
        preprocessor = get_column_preprocessing_pipeline(
                text_column=text_column,
                model_option=model_option,
                batch_size=batch_size,
                keep_unprocessed_data=keep_unprocessed_data
                )
    pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('model', model)
        ],
        memory=caching_path if caching_path and include_preprocessing else None)
    return pipeline

def generate_model_performance_summary(y_true, y_pred, write_results_to: str):
    """
    Generate and save a summary of the best model's performance on the test set
    and write it to a specified text file.

    Args:
        y_true: True labels for the test set.
        y_pred: Predicted labels for the test set.
        write_results_to (str): Path to save the model performance summary as a text file.

    Raises:
        IOError: If the directory for saving results does not exist.
    """
    dir = os.path.dirname(write_results_to) 
    if not os.path.exists(dir):
        raise IOError(f"Directory {dir} does not exist for saving best model results.")

    # generate a summary of the best model's performance on the test set
    summary_dict = {
            'f1_macro': f1_score(y_true, y_pred, average='macro'),
            'precision_macro': precision_score(y_true, y_pred, average='macro', zero_division=0),
            'recall_macro': recall_score(y_true, y_pred, average='macro', zero_division=0),
            'balanced_accuracy': balanced_accuracy_score(y_true, y_pred)
            }
    summary_df = pd.DataFrame.from_dict(summary_dict, orient='index').T
    classification_report_dict = classification_report(y_true, y_pred, output_dict=True)
    accuracy_from_classification_report = classification_report_dict.pop('accuracy', None)
    labeling_report = pd.DataFrame.from_dict(classification_report_dict, orient='index')

    # write best model results from test set to output file
    with open(write_results_to, 'w') as f:
        f.write(f"Model Performance Summary:\n{summary_df.to_string(index=False)}\n\n")
        f.write(f"Classification Report:\n{labeling_report.to_string()}\n")
        if accuracy_from_classification_report is not None:
            f.write(f"\nOverall Accuracy from Classification Report: {accuracy_from_classification_report:.4f}\n")
    print(f"Saved model performance summary to: {write_results_to}")

def run_scikit_learn_pipeline(param_grid: dict, 
                              X: pd.DataFrame, y, text_column: str, 
                              save_grid_results_to: str, save_best_model_results_to: str,
                              model_option: str='all-mpnet-base-v2', 
                              batch_size: int=64,
                              keep_unprocessed_data: bool=False,
                              caching_path: str | None = None,
                              include_preprocessing: bool=False):
    """
    Run a scikit-learn ML classification pipeline with grid search and cross-validation.
    The pipeline includes data preprocessing using sentence transformers for text embedding.
    The function performs training and validation on a hold-out set, evaluates model performance,
    and returns the best model pipeline untrained.
    Note that if include_preprocessing is True, the text_column must be present in the input data X
    and the preprocessing steps of the pipeline are executed.

    The metrics used for all models during cross-validation include:
        - Macro-F1 (primary metric for model selection)
        - Macro Precision
        - Macro Recall (Balanced Accuracy)

    The metrics used for the best model's evaluation include:
        - Macro-F1 (primary metric for model selection)
        - Macro Precision
        - Macro Recall (Balanced Accuracy)
        - Per-class F1 Scores
        - Classification Report

    Args:
        param_grid (dict): A dictionary specifying the hyperparameters to be tuned in the grid search.
        X: Input features (DataFrame or array-like).
        y: Target labels (Series or array-like).
        text_column (str): The name of the text column in the dataset.
        save_grid_results_to (str): Path to save the grid search cross-validation results as a CSV file.
        save_best_model_results_to (str): Path to save the best model's performance summary as a text file.
        model_option (str): The sentence transformer model to use for text embedding. Defaults to 'all-mpnet-base-v2'.
        batch_size (int): The batch size for processing text data. Defaults to 64.
        keep_unprocessed_data (bool): Whether to keep unprocessed data in the output. Defaults to False.
        caching_path (str): Path to use for caching the pipeline steps (Optional).
        include_preprocessing (bool): Whether to include the preprocessing step in the pipeline. Defaults to False.

    Raises:
        ValueError: If the specified text column is not found in the input data.
        IOError: If the directories for saving results or models do not exist

    Returns:
        Best model from the grid search.
    """

    def clone_model_with_params(model, params: dict):
        """
        Clone a scikit-learn model with specified parameters.
        The model must be part of a sklearn pipeline.

        Args:
            model: A scikit-learn Pipeline object containing the model to be cloned.
            params (dict): A dictionary of parameters to set for the cloned model.

        Returns:
            A new, untrained instance of the model with the specified parameters.
        """
        model_params = {key.replace('model__', ''): value 
                        for key, value in params.items() 
                        if key.startswith('model__')}
        model_class = type(model.named_steps['model'])
        unfitted_model = model_class(**model_params)
        return unfitted_model

    if include_preprocessing and text_column not in X.columns:
        raise ValueError(f"Text column '{text_column}' not found in input data.")

    # prepare data for training and validation on a hold-out set
    # this is an 80/20 split with stratification based on the target labels
    X_train, X_val, y_train, y_test = train_test_split(
            X, y, test_size=0.2, stratify=y, random_state=42)

    # get vanilla pipeline
    # fill in model for function model requirement compliance
    pipeline = get_data_preprocessing_pipeline(
            model=DummyClassifier(),
            text_column=text_column,
            model_option=model_option,
            batch_size=batch_size,
            keep_unprocessed_data=keep_unprocessed_data,
            caching_path=caching_path,
            include_preprocessing=include_preprocessing
            )

    # set up grid search with cv using StratifiedKFold and custom metrics/scoring
    cross_validator = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
    scorers = {
            'f1_macro': make_scorer(f1_score, average='macro'),
            'precision_macro': make_scorer(precision_score, average='macro'),
            'recall_macro': make_scorer(recall_score, average='macro'),
            'balanced_accuracy': make_scorer(balanced_accuracy_score),
            }
    # refit the best model based on best macro-f1 score
    grid_search = GridSearchCV(
            estimator=pipeline,
            param_grid=param_grid,
            cv=cross_validator,
            scoring=scorers,
            n_jobs=1,
            verbose=2,
            refit='f1_macro',
            error_score=0)

    # run grid search to train and validate models
    start_time = time.time()
    grid_search.fit(X_train, np.ravel(y_train))
    end_time = time.time()
    training_time = end_time - start_time

    # collect metrics from gridsearchcv to evaluate models--aka insights 
    print(f"Grid search training and validation completed in {training_time} seconds.") 
    results_df = pd.DataFrame(grid_search.cv_results_)

    # save all model results/report to csv from grid search
    results_df.to_csv(save_grid_results_to, index=False)
    print(f"Saved cross-validation results to: {save_grid_results_to}")

    # evaluate the best model on the hold-out validation set
    best_model = grid_search.best_estimator_
    y_test_pred = best_model.predict(X_val)
    generate_model_performance_summary(y_test, y_test_pred, save_best_model_results_to)

    # clone the best model, and return the untrained version 
    best_model_params = grid_search.best_params_
    best_unfitted_model = clone_model_with_params(best_model, best_model_params)
    return best_unfitted_model

# ------------- DeBerTa data preprocessing classes and functions ------------- 
# tokenization using DeBerTa tokenizer from transformers library
# tokenizer = DebertaV2Tokenizer.from_pretrained("microsoft/deberta-v3-base") 

def deberta_preprocessing_pipeline(data: pd.DataFrame, text_column: str="text", 
                                   tokenizer_model: str="microsoft/deberta-v3-base", max_tokens: int=512)-> dict:
    """
    Preprocess the text data using DeBerTa tokenizer from the transformers library.
    This preprocessing pipeline only does tokenization using the DeBerTa tokenizer.

    Args:
        data (pd.DataFrame): Input DataFrame containing news articles.
        text_column (str): The name of the text column to be tokenized. Defaults to "text".
        tokenizer_model (str): The DeBerTa tokenizer model to use. Defaults to "microsoft/deberta-v3-base".
        max_tokens (int): The maximum number of tokens for truncation/padding. Defaults to 512.

    Returns:
        dict: A dictionary containing tokenized text data (input_ids, attention_mask, labels).
    """
    # tokenize using DeBerTa tokenizer
    tokenizer = DebertaV2Tokenizer.from_pretrained(tokenizer_model)
    texts_list = data[text_column].astype(str).tolist()
    encodings = tokenizer(
        texts_list,
        padding='max_length',
        truncation=True,
        max_length=max_tokens,
        return_tensors='np'
    )
    return encodings 

def run_deberta_pipeline():
    # 1. allow a list of deberta models to be passed
    # 2. report:
    #       - data preprocessing steps
    #       - time to train
    #       - time to validate 
    #       - all metrics 
    #       - write time and metrics to file 
    #       - save the best performing model

    # deberta_preprocessing_pipeline()

    # train model on data

    # validate model on data
    pass

