"""
Description:
    This script contains the classes for data preprocessing on a given dataset for 
    US news articles, to be used in the baseline and DL model pipelines. 
    There are data cleaning and transformation classes for the scikit-learn ML 
    models due to the difference in data preprocessing requirements and libraries 
    used when compared to the DL models. 

Author:
    Osvaldo Hernandez-Segura

Date Created:
    November 22, 2025

Last Modified:
    December 6, 2025

References:
    Copilot, ChatGPT, scikit-learn documentation, sentence-transformers documentation, 
    pandas documentation
"""

import os
import pandas as pd
import numpy as np
import torch

from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.base import BaseEstimator, TransformerMixin
from sentence_transformers import SentenceTransformer
from langdetect import detect
from fasttext import load_model
from transformers import DebertaV2Tokenizer

# ------------- data preprocessing classes ------------- 

class TextLowercaseTransformer(BaseEstimator, TransformerMixin):
    """
    Transformer to convert text in the specified column to lowercase.
    """
    def __init__(self)-> None:
        """
        Initialize the TextLowercaseTransformer with no parameters.
        """
        pass

    def fit(self, X, y=None):
        """
        Fit method does nothing as this transformer does not learn anything from data.
        """
        return self

    def transform(self, X)-> np.ndarray:
        """
        Transform method to convert text in the specified column to lowercase.

        Args:
            X: Input data.

        Returns:
            np.ndarray: Numpy array with text in the specified column converted to lowercase.
        """
        if isinstance(X, pd.Series):
            strings = X.astype(str)
        elif isinstance(X, pd.DataFrame):
            strings = X.iloc[:, 0].astype(str)
        else:
            array = np.asarray(X)
            strings = pd.Series(array.ravel()).astype(str) 
        return strings.str.lower().values.reshape(-1, 1)

class TokenizerSentenceTransformer(BaseEstimator, TransformerMixin):
    """
    Transformer to tokenize text using a specified tokenizer model.
    To be used with scikit-learn ML models. 

    The default tokenizer has:
        1. embedding dimension of 768
        2. max sequence length of 512 tokens
    """
    def __init__(self, model_option: str='all-mpnet-base-v2', batch_size: int=64)-> None:
        """
        Initialize the TokenizerTransformer with the specified model option.

        Args:
            model_option (str): The sentence transformer model to use for tokenization. Defaults to 'all-mpnet-base-v2'.
            batch_size (int): The batch size for processing text data. Defaults to 64.
        """
        self.model_option = model_option
        self.sentence_model_ = None 
        self.batch_size = batch_size

    def fit(self, X, y=None):
        """
        Fit method does nothing as this transformer does not learn anything from data.
        """
        device = "cpu"
        if torch.cuda.is_available():
            device = "cuda"
        elif torch.backends.mps.is_available():
            device = "mps"
        print(f"Using device for sentence tranformer model: {device}")
        self.sentence_model_ = SentenceTransformer(self.model_option, device=device)
        return self

    def transform(self, X)-> np.ndarray:
        """
        Transform method to tokenize text using the specified tokenizer model.

        Args:
            X (pd.DataFrame): Input DataFrame.

        Returns:
            np.ndarray: Numpy array with tokenized text embeddings.
        """
        if isinstance(X, pd.Series):
            strings = X.astype(str)
        elif isinstance(X, pd.DataFrame):
            strings = X.iloc[:, 0].astype(str)
        else:
            array = np.asarray(X)
            strings = pd.Series(array.ravel()).astype(str)
        texts = strings.tolist()
        embeddings = self.sentence_model_.encode(texts, 
                                                 batch_size=self.batch_size,
                                                 convert_to_numpy=True,
                                                 show_progress_bar=True)
        return embeddings 

# ------------- data preprocessing functions ------------- 

# remove non-English articles 
def remove_non_english_articles(data: pd.DataFrame, text_column: str="text", 
                                memory_efficient: bool=True,
                                fasttext_model_path: str | None = None,
                                batch_size: int=128)-> pd.DataFrame:
    """
    Remove non-English articles from the DataFrame based on the specified text column.

    Args:
        data (pd.DataFrame): Input DataFrame containing news articles.
        text_column (str): The name of the text column to check for English language. Defaults to "text".
        memory_efficient (bool): Whether to use a memory-efficient method for language detection. Defaults to True.
        fasttext_model_path (str | None): Path to the FastText model for language detection. Required if memory_efficient is True.
        batch_size (int): The batch size for processing text data. Defaults to 128.

    Returns:
        pd.DataFrame: DataFrame containing only English articles.
    """

    def detect_english_language(text: list[str], 
                                memory_efficient: bool=True,
                                model=None, 
                                batch_size: int=128)-> list[bool]:
        """
        Detect if the given texts are in English.

        Args:
            text (list[str]): List of texts to check for English language.
            memory_efficient (bool): Whether to use a memory-efficient method for language detection. Defaults to True.
            model: FastText model for language detection. Required if memory_efficient is True.
            batch_size (int): The batch size for processing text data. Defaults to 128.

        Returns:
            list[bool]: List of boolean values indicating if each text is in English.
        """
        print("Detecting non-English language articles...")

        # using FastText model for language detection
        if memory_efficient: 
            if not model:
                raise ValueError("FastText model must be provided for memory-efficient language detection.")
            try:
                for i in range(0, len(text), batch_size):
                    batch = text[i:min(i+batch_size, len(text))]
                    language, _ = model.predict(batch, k=1)
                    yield from [lang[0].replace('__label__', '') == 'en' for lang in language]
            except:
                return False

        # using langdetect for language detection
        else: 
            for txt in text:
                try:
                    yield detect(txt) == 'en'
                except:
                    yield False

    if text_column not in data.columns:
        raise ValueError(f"Text column '{text_column}' does not exist in the DataFrame.")
    texts_list = data[text_column].fillna("").astype(str).tolist()

    # using FastText model for language detection
    if memory_efficient: 
        directory_name = os.path.dirname(fasttext_model_path) if fasttext_model_path else ""
        if not os.path.exists(directory_name):
            raise ValueError(f"FastText model path is invalid or does not exist: {fasttext_model_path}")
        language_model = load_model(fasttext_model_path)
        detected_language_mask = list(detect_english_language(texts_list, 
                                                             memory_efficient=memory_efficient,
                                                             model=language_model,
                                                             batch_size=batch_size))
        return data[detected_language_mask].reset_index(drop=True, inplace=False)

    # using langdetect for language detection
    else: 
        detected_language_mask = list(detect_english_language(texts_list, 
                                                             memory_efficient=memory_efficient))
        return data[detected_language_mask].reset_index(drop=True, inplace=False)

def write_df_to_parquet(data: pd.DataFrame, output_path: str)-> None:
    """
    Write the given DataFrame to a Parquet file at the specified output path.

    Args:
        data (pd.DataFrame): Input DataFrame to be written to Parquet.
        output_path (str): Path to save the Parquet file.

    Returns:
        None
    """
    print("Writing cleaned data to Parquet file...")

    directory_name = os.path.dirname(output_path)
    if not os.path.exists(directory_name):
        raise ValueError(f"Output path does not exist: {directory_name}")
    try:
        data.to_parquet(output_path, index=False)
        print(f"Cleaned data saved to {output_path}")
    except Exception as e:
        raise RuntimeError(f"Error writing DataFrame to Parquet file: {e}")


def clean_text_data_rows(data: pd.DataFrame, text_column: str="text", output_path: str="", 
                         memory_efficient: bool=True, fasttest_model_path: str | None = None,
                         batch_size: int=128)-> pd.DataFrame:
    """
    Clean the text data by removing rows with null values in the specified text column
    and removing non-English articles. Optionally save the cleaned data to a Parquet file.

    Args:
        data (pd.DataFrame): Input DataFrame containing news articles.
        text_column (str): The name of the text column to be cleaned. Defaults to "text".
        output_path (str): Path to save the cleaned data as a Parquet file. Defaults to an empty string (no saving).
        memory_efficient (bool): Whether to use a memory-efficient method for language detection. Defaults to True.
        fasttest_model_path (str | None): Path to the FastText model for language detection. Required if memory_efficient is True.
        batch_size (int): The batch size for processing text data. Defaults to 128.

    Returns:
        pd.DataFrame: Cleaned DataFrame with non-English articles and null text rows removed.
    """
    print("Cleaning text data rows...")
    new_data = None
    if not output_path:
        print("No output path provided; proceeding without saving cleaned data.")
    try:
        old_num_rows = data.shape[0]
        new_data = data.dropna(subset=[text_column])
        new_data = remove_non_english_articles(new_data, text_column=text_column,
                                               memory_efficient=memory_efficient,
                                               fasttext_model_path=fasttest_model_path,
                                               batch_size=batch_size)
        if output_path: 
            write_df_to_parquet(new_data, output_path)

        # report cleaning stats
        removed_rows = old_num_rows - new_data.shape[0]
        print("Text data cleaning completed.")
        print(f"Cleaned data size: {new_data.shape}")
        print(f"Removed {removed_rows} ({round(removed_rows / old_num_rows * 100, 2)}%) rows during cleaning.")
        return new_data
    except Exception as e:
        raise RuntimeError("Error cleaning text data: {%s}" % e)

def get_text_embeddings(data: pd.DataFrame, text_column: str="text", 
                        model_option: str='all-mpnet-base-v2', batch_size: int=64)-> np.ndarray:
    """
    Get text embeddings for the specified text column using a sentence transformer model.

    Args:
        data (pd.DataFrame): Input DataFrame containing news articles.
        text_column (str): The name of the text column to be embedded. Defaults to "text".
        model_option (str): The sentence transformer model to use for text embedding. Defaults to 'all-mpnet-base-v2'.
        batch_size (int): The batch size for processing text data. Defaults to 64.

    Returns:
        np.ndarray: Numpy array with text embeddings.
    """
    tokenizer = TokenizerSentenceTransformer(model_option=model_option, batch_size=batch_size)
    tokenizer.fit(None)
    tokens = tokenizer.transform(data[[text_column]])
    return tokens

# ------------- DeBerTa data preprocessing classes and functions ------------- 
# tokenization using DeBerTa tokenizer from transformers library
# tokenizer = DebertaV2Tokenizer.from_pretrained("microsoft/deberta-v3-base") 

def deberta_preprocessing_pipeline(data: pd.DataFrame, text_column: str="text", 
                                   tokenizer_model: str="microsoft/deberta-v3-base", max_tokens: int=512)-> dict:
    """
    Preprocess the text data using DeBerTa tokenizer from the transformers library.
    This preprocessing pipeline only does tokenization using the DeBerTa tokenizer.

    Args:
        data (pd.DataFrame): Input DataFrame containing news articles.
        text_column (str): The name of the text column to be tokenized. Defaults to "text".
        tokenizer_model (str): The DeBerTa tokenizer model to use. Defaults to "microsoft/deberta-v3-base".
        max_tokens (int): The maximum number of tokens for truncation/padding. Defaults to 512.

    Returns:
        dict: A dictionary containing tokenized text data (input_ids, attention_mask, labels).
    """
    # tokenize using DeBerTa tokenizer
    tokenizer = DebertaV2Tokenizer.from_pretrained(tokenizer_model)
    texts_list = data[text_column].astype(str).tolist()
    encodings = tokenizer(
        texts_list,
        padding='max_length',
        truncation=True,
        max_length=max_tokens,
        return_tensors='np'
    )
    return encodings 

def run_deberta_pipeline():
    # 1. allow a list of deberta models to be passed
    # 2. report:
    #       - data preprocessing steps
    #       - time to train
    #       - time to validate 
    #       - all metrics 
    #       - write time and metrics to file 
    #       - save the best performing model

    # deberta_preprocessing_pipeline()

    # train model on data

    # validate model on data
    pass


