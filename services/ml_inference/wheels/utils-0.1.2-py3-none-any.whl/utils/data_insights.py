"""
Description:
    This file contains the class for data understanding and insights (EDA),
    prior to data preprocessing for both baseline and DL model workflows,
    and baseline and DL model visual evaluations--that follow CRISP-DM 
    methodology.

Author:
    Osvaldo Hernandez-Segura

Date Created:
    November 19, 2025

Last Updated:
    November 26, 2025

References:
    Copilot, ChatGPT, Matplotlib documentation, Pandas documentation, 
    fasttext documentation, spacy documentation, StackOverflow
"""
import pandas as pd
import os
import sys
import humanize
import spacy
import fasttext
import re

from transformers import DebertaV2Tokenizer

class DataInsights:
    """
    A class to generate data insights for raw US article data.
    """

    def __init__(self, data_file: str, 
                 text_feature_name: str, output_feature_name: str,
                 output_file: str,
                 token_threshold: int=512,
                 process_size_percent: float=1.0,
                 include_publication_stats: bool=False,
                 path_to_nlp_model: str | None = None)-> None:
        """
        Initialize the DataInsights class with the data file path.
        The default text feature name is "text" and the default output feature 
        name is "bias_rating".

        Args:
            data_file (str): Path to the data file (CSV or Parquet format).
            text_feature_name (str): Name of the text feature column.
            output_feature_name (str): Name of the output feature column.
            output_file (str): Path to save the output results.
            token_threshold (int, optional): Token limit threshold. Defaults to 512.
            process_size_percent (float, optional): Percentage of the dataset to process. Defaults to 1.0 (100%).
            include_publication_stats (bool, optional): Whether to include publication statistics. Defaults to False.
            path_to_nlp_model (str | None, optional): Path to a NLP model for language detection. Defaults to None.

        Returns:
            None
        """
        # check if data file and output file directories exist
        if not os.path.exists(data_file):
            print(f"Error: The data file {data_file} does not exist.")
            sys.exit(1)

        # ensure the file format is supported
        if not data_file.endswith('.csv') and not data_file.endswith('.parquet'):
            print("Error: Unsupported data file format. Please provide a CSV or Parquet file.")
            sys.exit(1)

        directory = os.path.dirname(data_file)
        if not os.path.exists(directory):
            print(f"Error: The data file directory {directory} does not exist.")
            sys.exit(1)

        directory = os.path.dirname(output_file)
        if not os.path.exists(directory):
            print(f"Error: The output file directory {directory} does not exist.")
            sys.exit(1)

        self.output_file = output_file
        self.data_file = data_file
        self.text_feature_name = text_feature_name
        self.output_feature_name = output_feature_name
        self.token_threshold = token_threshold
        self.include_publication_stats = include_publication_stats

        if not path_to_nlp_model or not os.path.exists(path_to_nlp_model):
            print("\nWarning: fasttext NLP model path not provided or does not exist. No language detection model will be used.")
            print("NLP model suggestion is: lid.176.bin")
            print("NLP model suggestion download link is: https://dl.fbaipublicfiles.com/fasttext/supervised-models/lid.176.bin\n")
            self.path_to_nlp_model = None
        else:
            self.path_to_nlp_model = path_to_nlp_model

        try:
            if data_file.endswith('.parquet'):
                self.data = pd.read_parquet(data_file)
            elif data_file.endswith('.csv'):
                self.data = pd.read_csv(data_file)
            else:
                print("Error: Unsupported data file format. Please provide a CSV or Parquet file.")
                sys.exit(1)

            # process only a percentage of the data if specified    
            if process_size_percent < 1.0:
                data_size = int(len(self.data) * process_size_percent)
                self.data = self.data.iloc[0:data_size]
                print(f"Working with only {process_size_percent*100}% of the data: {data_size} rows.")
        except Exception as e:
            print(f"Error reading the data file: {e}")
            sys.exit(1)

    def get_data_location(self)-> dict:
        """
        Get the data storage size on disk (human interpretable) and relative 
        location to the program which calls this function.

        Returns: 
            dict: A dictionary containing data size and data location.
        """
        print("Getting data location for file...")

        # data storage size on disk
        data_bytes = os.path.getsize(self.data_file)

        # covert bytes to human readable format
        human_readable_size = humanize.naturalsize(data_bytes)

        # relative data location from project root
        relative_path = self.data_file
        deliverable = {
                "data size": human_readable_size,
                "data location": relative_path
                }
        return deliverable

    def get_data_overview(self, target_feature: str="bias_rating")-> dict:
        """
        Get an overview of the data including shape, target feature distribution,
        missing values, and duplicate rows.
        
        Args:
            target_feature (str, optional): The name of the target feature column. Defaults to "bias_rating".

        Returns:
            dict: A dictionary containing data overview statistics.
        """
        print("Getting data overview...")

        # no. rows and columns
        shape = self.data.shape
        rows = shape[0]
        columns = shape[1]

        # target feature distribution, absolute and percentage values
        # (left, center, right)
        target_distribution = None
        if target_feature and target_feature in self.data.columns:
            abs_target_distribution = self.data[target_feature].value_counts()
            percent_target_distribution = self.data[target_feature].value_counts(normalize=True) * 100
            target_distribution = pd.DataFrame({
                'absolute': abs_target_distribution,
                'percentage': percent_target_distribution 
            })
        else:
            print(f"Target feature '{target_feature}' not provided or not found in data columns.")

        # columns with missing values (absolute and percentage)
        cols_missing_values = []
        for col in self.data.columns:
            missing_count = self.data[col].isnull().sum()

            if missing_count > 0:
                missing_percent = (missing_count / rows) * 100
                cols_missing_values.append([col, missing_count, missing_percent])

        # rows with missing values (absolute and percentage)
        rows_with_missing_values_count = self.data.isnull().any(axis=1).sum()

        # no. and percent of duplicate rows
        dup_rows_count = self.data.duplicated().sum()
        dup_rows_percent = (dup_rows_count / rows) * 100

        deliverable = {
                "shape": (rows, columns),
                "target distribution": target_distribution,
                "columns with missing values": cols_missing_values if cols_missing_values else None,
                "rows with missing values": (rows_with_missing_values_count, (rows_with_missing_values_count / rows) * 100),
                "duplicate rows": (dup_rows_count, dup_rows_percent)
                }
        return deliverable

    def get_token_statistics(self, text_column: str="text", token_threshold: int=512)-> dict:
        """
        Get token statistics for the specified text column using a transformer tokenizer 
        for Microsoft's DeBERTa v3 base model.

        Args:
            text_column (str, optional): The name of the text column to analyze. Defaults to "text".
            token_threshold (int, optional): The token limit threshold. Defaults to 512.

        Returns:
            dict: A dictionary containing token statistics.
        """
        print("Getting token statistics...")

        if not text_column:
            print("No text column specified for token statistics.")
            return {}
        elif text_column not in self.data.columns:
            print(f"Column '{text_column}' does not exist in the data.")
            return {}

        tokenizer = DebertaV2Tokenizer.from_pretrained("microsoft/deberta-v3-base") 

        # no. of tokens, using a transformer (min, max, avg) 
        tokens = tokenizer(self.data[text_column].astype(str).tolist(), truncation=False)['input_ids']
        token_lengths = [len(token_list) for token_list in tokens]

        # no. and percent of data points with tokens exceeding 
        # <abritrary> token limit
        exceeding_threshold_count = sum(1 for lenn in token_lengths if lenn > token_threshold)
        exceeding_threshold_percent = (exceeding_threshold_count / len(token_lengths)) * 100

        deliverable = {
                "token count": {
                                "min": min(token_lengths),
                                "max": max(token_lengths),
                                "avg": sum(token_lengths) / len(token_lengths)
                },
                "exceeding token threshold": (exceeding_threshold_count, exceeding_threshold_percent)
                }
        return deliverable

    def get_text_statistics(self, text_column: str="text", publication_column: str="source", 
                            include_publication_stats: bool=False,
                            top_publications: int=10, 
                            batch_size: int=128)-> dict:
        """
        Get text statistics for the specified text column including sentence length,
        word length, non-English articles, HTML tags, and top unique publications.
        Note that this function uses the spacy library for NLP processing and leverages
        two-core batch processing for efficient processing.

        Args:
            text_column (str, optional): The name of the text column to analyze. Defaults to "text".
            publication_column (str, optional): The name of the publication/source column. Defaults to "source".
            include_publication_stats (bool, optional): Whether to include publication statistics. Defaults to False.
            top_publications (int, optional): The number of top publications to return. Defaults to 10.
            batch_size (int, optional): The batch size for spacy processing. Defaults to 128.

        Returns:
            dict: A dictionary containing text statistics.
        """

        def detect_language(lang_detect_model: fasttext.FastText._FastText, text: list[str], batch_size: int=128)-> list[str]:
            """
            Detect the language of the given text using the provided fasttext language detection model.

            Args:
                lang_detect_model (fasttext.FastText._FastText): The fasttext language detection model.
                text (list[str]): A list of text strings for which to detect the language.
                batch_size (int, optional): The batch size for processing. Defaults to 128.

            Returns:
                list[str]: A list of detected language codes.
            """
            for i in range(0, len(text), batch_size):
                text_batch = text[i: min(i + batch_size, len(text))]
                labels, _ = lang_detect_model.predict(text_batch, k=1) # top 1 language label
                for label in labels:
                    yield label[0].replace("__label__", "") 


        print("Getting text statistics...")

        if text_column not in self.data.columns:
            print(f"Column '{text_column}' does not exist in the data.")
            return {}
        if include_publication_stats and publication_column not in self.data.columns:
            print(f"Column '{publication_column}' does not exist in the data.")
            return {}

        # load lightweight spacy English model
        # using blank model for faster processing and
        # adding only the sentencizer component for sentence segmentation
        nlp = spacy.blank("en")
        nlp.add_pipe("sentencizer")

        min_sentence_len = float('inf')
        max_sentence_len = total_sentence_len = 0
        min_word_len = float('inf')
        max_word_len = total_word_len = 0
        non_english_count = 0

        # clean text for spacy processing
        # self.data[text_column] = self.data[text_column].fillna("")
        text_list = self.data[text_column].fillna("").astype(str).tolist()

        for doc in nlp.pipe(text_list, batch_size=batch_size, n_process=2):
            sentence_count = sum(1 for sent in doc.sents)
            min_sentence_len = min(min_sentence_len, sentence_count)
            max_sentence_len = max(max_sentence_len, sentence_count)
            total_sentence_len += sentence_count

            word_count = sum(1 for token in doc if token.is_alpha)
            min_word_len = min(min_word_len, word_count)
            max_word_len = max(max_word_len, word_count)
            total_word_len += word_count

        # accumulate non-English article count
        # no. and percent non-English articles (langdetect library)
        non_english_count = None
        if not self.path_to_nlp_model:
            print("No NLP model path provided for language detection. Skipping non-English article detection.")
        else:
            lang_detect_model = fasttext.load_model(self.path_to_nlp_model)
            detected_languages = detect_language(lang_detect_model, text_list, batch_size)
            non_english_count = sum(1 for lang in detected_languages if lang != 'en')
        
        # no. and percent HTML tags present in the data overall
        # using a simple and lightweight regular expression
        html_regex = re.compile(r'<[^<]+>')
        html_tag_count = sum(1 for text in text_list if html_regex.search(text))
        html_tag_percent = (html_tag_count / len(self.data)) * 100

        # no. and percent of unique news publications
        top_unique_publications = None
        if include_publication_stats:
            abs_publications_count = self.data[publication_column].value_counts()
            percent_publications_count = self.data[publication_column].value_counts(normalize=True) * 100
            unique_publications = pd.DataFrame({
                "absolute": abs_publications_count,
                "percentage": percent_publications_count 
            })

            # get top most frequent publications
            top_unique_publications = unique_publications.sort_values(
                    axis=0, 
                    ascending=False,
                    by="absolute").head(top_publications)

        deliverable = {
                "sentence length": {
                    "min": min_sentence_len,
                    "max": max_sentence_len,
                    "avg": total_sentence_len / len(self.data) 
                    },
                "word length": {
                    "min": min_word_len,
                    "max": max_word_len,
                    "avg": total_word_len / len(self.data)
                    },
                "non english articles": (non_english_count, (non_english_count / len(self.data)) * 100),
                "html tags": (html_tag_count, html_tag_percent),
                "top unique publications": top_unique_publications
                }
        return deliverable

    def get_data_statistics(self)-> str:
        """
        Get basic data statistics using pandas describe function.

        Returns:
            str: A string representation of the data statistics.
        """
        print("Getting data statistics...")
        return self.data.describe().T.to_string()

    def humanize_insights(self, value)-> str:
        """
        Custom function to humanize different types of insights values.
        
        Args:
            value: The insight value to humanize.

        Returns:
            str: A human-readable string representation of the insight value.
        """
        if isinstance(value, pd.DataFrame):
            return value.to_string()
        if isinstance(value, tuple) and len(value) == 2:
            if len(value) == 2:
                if isinstance(value[0], int) and isinstance(value[1], int):
                    return f"{value[0]}, {value[1]}"
                return f"{value[0]} ({value[1]:.2f}%)"
            elif len(value) == 3:
                return f"{value[0]} ({value[1]:.2f}%, {value[2]:.2f}%)"
            else:
                return value
        if isinstance(value, dict):
            res = "\n"
            for k, v in value.items():
                res += f"{k}: {self.humanize_insights(v)}\n\n" 
            return res
        if isinstance(value, int) or isinstance(value, float):
            return f"{value:.2f}"
        if isinstance(value, list):
            res = ""
            for item in value:
                res += f"\n{item[0]}: {item[1]} ({item[2]:.2f}%)"
            return res
        return str(value) if value else "No Data Available"

    def write_insights_to_file(self, insights: str)-> None:
        """
        Write the data insights to the specified output file in a human 
        readable format.

        Args:
            insights (str): The insights string to write to the file.

        Returns:
            None
        """
        print("Writing insights to file...")
        try:
            with open(self.output_file, 'w') as f:
                f.write("Data Insights Report\n")
                f.write("====================\n\n")
                f.write(insights)
            print(f"Data insights written to {self.output_file}")
        except Exception as e:
            print(f"Error writing insights to file: {e}")

    def get_insights(self)-> str:
        """
        Get all data insights and write them to the output file.
        Humanizes the insights for better readability.

        Returns:
            str: A human-readable string representation of all data insights.
        """
        print("Generating data insights...")
        insights = {
                "data location": self.get_data_location(),
                "data overview": self.get_data_overview(target_feature=self.output_feature_name),
                "token statistics": self.get_token_statistics(text_column=self.text_feature_name, 
                                                              token_threshold=self.token_threshold),
                "text statistics": self.get_text_statistics(include_publication_stats=self.include_publication_stats),
                "data statistics": self.get_data_statistics()
                }

        # humanize insights
        string_insights = ""
        for key, value in insights.items():
            string_insights += f"{key}:\n{self.humanize_insights(value)}\n\n"

        self.write_insights_to_file(string_insights)
        return string_insights


# generate visual reports of the data insights using matplotlib--for future work

